I = imread('hotpot.jpg');

[Ic, T] = carv(I, 50, 50);
imshow(Ic)